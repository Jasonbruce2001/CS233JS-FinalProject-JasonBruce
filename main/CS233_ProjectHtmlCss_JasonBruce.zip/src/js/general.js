/**
 * CSS files
 */
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/styles.css';

/**
 * Bootstrap JS File
 */
import 'bootstrap';

